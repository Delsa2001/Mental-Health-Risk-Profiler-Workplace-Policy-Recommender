from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)

# Load model and label encoder
model = joblib.load("mental_health_rf_model.pkl")
label_encoder = joblib.load("label_encoder.pkl")


@app.route('/', methods=['GET', 'POST'])
def index():
    prediction = None

    if request.method == 'POST':
        try:
            age = int(request.form['age'])
            gender = int(request.form['gender'])  # Assuming already encoded
            family_history = int(
                request.form['family_history'])  # 1 = Yes, 0 = No
            benefits = int(request.form['benefits'])  # 1 = Yes, 0 = No
            # e.g., already encoded
            work_interfere = int(request.form['work_interfere'])
            care_options = int(request.form['care_options'])  # 1 = Yes, 0 = No
            anonymity = int(request.form['anonymity'])  # 1 = Yes, 0 = No

            # Create array for prediction
            input_data = np.array([[age, gender, family_history, benefits,
                                    work_interfere, care_options, anonymity]])

            pred = model.predict(input_data)
            prediction = label_encoder.inverse_transform(pred)[0]

        except Exception as e:
            prediction = f"Error: {str(e)}"

    return render_template("index.html", prediction=prediction)


if __name__ == '__main__':
    app.run(debug=True)
